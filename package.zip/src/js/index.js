// fixed header
const header = document.querySelector(".header");

window.addEventListener("scroll", () => {
  if (window.scrollY > 110) {
    header.classList.add("header_change");
  } else {
    header.classList.remove("header_change");
  }
});

//responsive menu
const headerNav = document.querySelector(".header-menu");
const menuLinks = document.querySelectorAll(".menu-link");
const burgerMenu = document.querySelector(".burger-menu");


burgerMenu.addEventListener("click", () => {
  headerNav.classList.toggle("active");
});

// const closeBtn = document.querySelector(".close-btn");
// closeBtn.addEventListener("click", () => {
//   headerNav.classList.remove("active");
// });

menuLinks.forEach((link) => {
  link.addEventListener("click", (event) => {
    event.preventDefault();

    const targetSelector = link.dataset.goto;
    const targetSection = document.querySelector(targetSelector);

    targetSection.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });

    headerNav.classList.remove("_active");
  });
});

// glide
document.addEventListener("DOMContentLoaded", function () {
  new Glide(".glide-reviews", {
    type: "carousel",
    startAt: 0,
    autoplay: 1000,
    hoverpause: true,
    perView: 1,
    animationDuration: 3000,
    animationTimingFunc: "ease-in-out",
    breakpoints: {
      990: {
        perView: 1,
      },
    },
  }).mount();
});

// date difference
document.addEventListener("DOMContentLoaded", function () {
  const yearsNum = document.querySelectorAll(".years-num");
  const diffYears =
    new Date().getFullYear() - new Date(2012, 6, 1).getFullYear();

  yearsNum.forEach((span) => {
    span.textContent = diffYears;
  });
});

//animated number

const time = 5000;
const step = 1;

function outNum(num, elem) {
  let e = document.querySelectorAll(elem);
  n = 0;
  let t = Math.round(time / (num / step));
  let interval = setInterval(() => {
    n = n + step;
    if (n == num) {
      clearInterval(interval);
    }
    e.forEach(element => {
      element.innerHTML = n + '%'; 
    });
  }, t);
}

outNum(100, ".out");